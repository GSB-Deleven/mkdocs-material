This config lives in 

```sh
/root/.config/neofetch/config.conf
```
if you only have a `root` user

---

or in 

```sh
/home/$USER/.config/neofetch/config.conf
```
if you have a `home` for your users