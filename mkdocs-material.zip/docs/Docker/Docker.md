icon: simple/docker
# Docker
show logs in terminal of the Docker conatiner
```
docker logs --timestamps --follow CONTAINERID
```

## docker compose files
Are all [here](https://github.com/GSB-Deleven/mkdocs-material/tree/1b7b01e7732118f7e1bf828b65608ff73c749401/docs/scripts-and-snippets/docker-compose%20files)