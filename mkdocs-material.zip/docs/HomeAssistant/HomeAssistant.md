icon: simple/homeassistant

# Home Assistant