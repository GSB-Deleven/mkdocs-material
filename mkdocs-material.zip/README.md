# Built with Material for MkDocs
[![Built with Material for MkDocs](https://img.shields.io/badge/Material_for_MkDocs-526CFE?style=for-the-badge&logo=MaterialForMkDocs&logoColor=white)](https://squidfunk.github.io/mkdocs-material/)

## Todo:

- [ ] add the following to the Commands Page
    ```sh
    /gamerule sendCommandFeedback false  
    ```  
    will affect "whether the feedback from commands executed by a player should show up in chat."
    
    or
    ```sh
    /gamerule commandblockoutput false
    ```

- [x] move Todo List to here

- [ ] Delete old HomeLab GitHub Repo
- [ ] Add Stuff from Obsidian and Anytype
- [ ] Use Blog


- [ ] Home Assistant
    - [ ] Check why light in office tuns on at night
        - [ ] may Omada turns on and off and the light is set to come back on after powerloss or on power on 

- [ ] MineCraft
    - [ ] Create ATM 9 Section
        - [ ] Starter Guide with Usefull Commands 
    - [ ] 